"use strict"

const $ = (id) => document.getElementById(id);

const screens =[
    "home",
    "setup",
    "loading",
    "error",
    "quiz",
    "result",
    "review"
];

function show(name) {
    screens.forEach(screen => {
        $("s-" + screen).classList.remove("active");
    });

    $("s-" + name).classList.add("active");

    window.scrollTo(0, 0);
}

function IsGet(key, fallback) {
    try {
        
        const value = localStorage.getItem(key);

        return value === null ? fallback : value;

    } catch (error) {
        return fallback
    }
}


function IsSet(key, value) {
    try {

        localStorage.setItem(key, value);

    } catch (error) {
        
    }
}

function loadStats() {
    $("bestScore").textContent = IsGet("qm_best", "0") + "%";

    $("playedCount").textContent = IsGet("qm_played", "0");
}

function saveStats(pct) {
    const best = parseInt(IsGet("qm_best", "0"), 10);

    const played = parseInt(IsGet("qm_played", "0"), 10);

    if (pct > best) {

        IsSet("qm_best", String(pct));
    }

    IsSet("qm_played", String(played + 1));

    loadStats();
}

let settings = {
    category: 18,
    difficulty: "easy",
    type: "multiple",
    amount: 10,
};

function initChips() {

    document.querySelectorAll("[data-field]").forEach(group => {
       group.addEventListener("click", event => {
        const button = event.target.closest(".chip");
        if (!button) return;

        group.querySelectorAll(".chip").forEach(chip => chip.classList.remove("sel"));
        button.classList.add("sel");

        settings[group.dataset.field] = button.dataset.v;
    
    });

});
}

let questions = [];

function decode(text) {
    
    const element = document.createElement("textarea");
    element.innerHTML = text;
    return element.value;
}

function shuffle(array) {
    array = array.slice();
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

async function fetchQuestions() {
    
    show("loading");

    try{
        let type = settings.type === "mixed" ? "" : settings.type;

        const params = new URLSearchParams({
            amount: settings.amount,
            category: settings.category,
            difficulty: settings.difficulty,
        });

        if (type) {
            params.append("type", type);
        }

const response = await fetch("https://opentdb.com/api.php?" + params.toString());

if (!response.ok) {
    throw new Error("Network response was not ok");
}

const data = await response.json();

if (data.response_code === 1) {
    throw new Error("few");
}

if (data.response_code !== 0 || !data.results || data.results.length === 0) {
    throw new Error("bad");
}

questions = data.results.map(question => {

    console.log("Questions received:", questions);
    console.log("Number of questions:", questions.length)

    const correct = decode(question.correct_answer);

    return {
        question: decode(question.question),
        correctAnswer: correct,

        options: shuffle([
            correct,
            ...question.incorrect_answers.map(decode)
        ]),

        category: decode(question.category)

    };
});


startQuiz();

    } catch (error) {
        $("errMsg").textContent = error.message == "few" ? "not enough questions for this combination.Try different setting."
        : "Please check your internet connection and try again.";
        show("error");

    }
}


function setupErrorButtons() {
    $("errHome").onclick = () => {
        show("home");
    };

    $("errRetry").onclick = fetchQuestions;
}

let current = 0 ;
let score = 0;
let selected = null;
let answers = [];

let timer = null;
let timeLeft = 15 ;

const T = 15;

function startQuiz() {

    current = 0;
    score = 0;
    answers = [];

    show("quiz");
    showQuestion();
}

function showQuestion() {
    stopTimer();

    selected = null;
    
    const question = questions[current];

    if(!question) {
        console.error("Question does not exist :", current);
        return;
    }
    $("qCounter").textContent = `Question ${current + 1} / ${questions.length}`;

    $("qCat").textContent = question.category;

    $("qText").textContent = question.question;

    $("scoreNow").textContent = score;

    $("feedback").textContent = "";

    $("feedback").className = "feedback";


    const progress = Math.round(((current + 1) / questions.length)* 100);

    $("progFill").style.width = progress + "%";

    const answerBox = $("answers");

    answerBox.innerHTML = "" ;

    question.options.forEach(option => {
        const button = document.createElement("button");

        button.className = "opt";

        button.textContent = option;

        button.onclick = () => {
            selectAnswer(option , question);
        };

        answerBox.appendChild(button);

        });

        $("nextBtn").disabled = true;

        $("nextBtn").textContent = current === questions.length - 1 ? "Finish Quiz" : "Next" ;

        startTimer();
}


function selectAnswer(option , question) {
    if (selected !== null) return;

    selected = option;

    stopTimer();

    const correct = option === question.correctAnswer;

    if(correct) {
        score++;
    }

    document.querySelectorAll(".opt").forEach(button => {
        button.disabled = true;

        if(button.textContent === question.correctAnswer){
            button.classList.add("correct");
        } else if (button.textContent === option) {
            button.classList.add("wrong");
        }
    });

    $("feedback").textContent = correct ? "Correct Answer !" : "Wrong Answer";

    $("feedback").className = "feedback" + (correct ? "ok" : "bad");
   
    $("scoreNow").textContent = score;

    $("nextBtn").disabled = false ; 

    answers.push({
        question: question.question, 
        correctAnswer: question.correctAnswer,
        userAnswer: option,
        isCorrect: correct
    });
}

function startTimer() {
    stopTimer();
    
    timeLeft = T ; 
    updateTimer();
    timer = setInterval(() => {
        timeLeft--;

        updateTimer();

        if(timeLeft <= 0) {
            stopTimer();
            timeUp();
        }

    }, 1000);
}

function stopTimer() {

    if (timer) {
        clearInterval(timer);
        timer = null; 
    }
}

function updateTimer() {

    $("timeLeft").textContent = timeLeft;

    $("timerBadge").classList.toggle("low", timeLeft <= 5);
}

function timeUp() {
    if(selected !== null) return;

    const question = questions[current];

    document.querySelectorAll(".opt").forEach(button => {
        button.disabled = true;
        if(button.textContent === question.correctAnswer){
            button.classList.add("correct");
        }
    });

    $("feedback").textContent = "Time's Up!";

    $("feedback").className = "feedback bad";
    answers.push({

        question : question.question,
        correctAnswer : question.correctAnswer,
        userAnswer: null ,
        isCorrect: false
    });

    selected = "__timeout__";

    $("nextBtn").disabled = false ;

}


function nextQuestion() {

    console.log("Next Clicked");
    console.log("Current:", current);
    console.log("Total:", questions.length)
    if(selected === null) return;

    stopTimer();

    if(current < questions.length - 1){
        current++;
        showQuestion();
    } else{
        showResult();
    }
}

function showResult() {
    const total = questions.length;
    const correct = score ; 
    const wrong = total - correct ;
    const pct = Math.round((correct / total) * 100 );

    show("result");

    $("resPct").textContent = pct + "%";
    $("resFrac").textContent = `${correct} / ${total}`;
    $("cCorrect").textContent = correct ;
    $("cWrong").textContent = wrong ;
    $("cAcc").textContent = pct + "%" ; 
    $("perfMsg").textContent = pct >= 90 ? "Quiz Champion! Outstanding performance." 
    : pct >= 75 ? "Excellent Work! Keep it up."
    : pct >= 50 ? "Good Job! You can improve even more"
    :"Keep Practicing! Try again and improve your score.";
    
    saveStats(pct);
}

function esc(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
    
}

function showReview() {
    const list = $("reviewList");
    list.innerHTML = "";

    answers.forEach((answer , index) => {
        const userAnswer = answer.userAnswer === null ? "No answer (time expired)" : answer.userAnswer;
        const div = document.createElement("div");
        div.className = "card" ;
        div.innerHTML= `<p style="font-weight:600">Q${index + 1}.${esc(answer.question)}</p> 
        <p class="dim">Your Answer: 
        <strong style="color:var(--text)"> ${esc(userAnswer)} </strong>
        </p>
        <p class="dim"> Correct Answer:
        <strong style="color:var(--text)"> ${esc(answer.correctAnswer)} </strong>
        </p>
        <p style="font-weight:700; color:${answer.isCorrect ? "var(--ok)" : "var(--bad)"}">
          ${answer.isCorrect ? "✓ correct" : "✘ Incorrect" }
          </p> `;
          list.appendChild(div);
    }
  );

  show("review");

}


function toggleTheme() {
    const currentTheme = document.body.getAttribute("data-theme");
    const nextTheme = currentTheme === "dark" ? "light" : "dark";
    applyTheme(nextTheme);

    IsSet("qm_theme", nextTheme);
}

function applyTheme(theme) {
    document.body.setAttribute("data-theme" , theme);
    $("themeIcon").className = theme === "dark" ? "fa-solid fa-moon" : "fa-solid fa-sun";
}


function resetQuiz() {
    stopTimer();
    current = 0;
    score = 0;
    answers = [];
    questions = [];
    selected = null;
}


function init() {
    applyTheme(IsGet("qm_theme" , "dark"));
    loadStats();
    initChips();
    $("themeBtn").onclick = toggleTheme;
    $("startBtn").onclick = () => {
        show("setup");
    };

    $("setupBack").onclick = () => {
        show("home");
    };

    $("setupStart").onclick = fetchQuestions;
    setupErrorButtons();

    $("nextBtn").onclick = nextQuestion;
    
    $("reviewBtn").onclick = showReview;

    $("tryAgainBtn").onclick = () => {
        resetQuiz();
        fetchQuestions();
    };

    $("resHomeBtn").onclick = () => {
        resetQuiz();
        show("home");
    };

    $("reviewBack").onclick = () => {
        show("result");
    };

    $("reviewHomeBtn").onclick = () => {
        resetQuiz();
        show("home");
    };
}

document.addEventListener("DOMContentLoaded" , init);

